<?php
/**
* 
*/

// Disallow direct access.
defined('ABSPATH') or die("Access denied");

/**
* 
*/
class CJT_Framework_Developer_Interface_Block_Parameters_Types_Raw
extends CJT_Framework_Developer_Interface_Block_Parameters_Types_Text {} // End class.
