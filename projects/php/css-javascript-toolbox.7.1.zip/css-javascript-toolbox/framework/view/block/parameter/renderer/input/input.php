<?php
/**
* 
*/

/**
* 
*/
class CJT_Framework_View_Block_Parameter_Renderer_Input_Input
extends CJT_Framework_View_Block_Parameter_Base_Scalar {
	
	/**
	* put your comment there...
	* 
	*/
	public function enqueueStyles() {
		return array('framework:view:block:parameter:renderer:input:public:css:input');
	}

} // End class.