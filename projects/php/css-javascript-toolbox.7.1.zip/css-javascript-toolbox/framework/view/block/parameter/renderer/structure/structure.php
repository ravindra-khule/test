<?php
/**
* 
*/

/**
* 
*/
class CJT_Framework_View_Block_Parameter_Renderer_Structure_Structure
extends CJT_Framework_View_Block_Parameter_Base_List {
	
	/**
	* put your comment there...
	* 
	*/
	public function enqueueStyles() {
		return array('framework:view:block:parameter:renderer:structure:public:css:structure');
	}

} // End class.