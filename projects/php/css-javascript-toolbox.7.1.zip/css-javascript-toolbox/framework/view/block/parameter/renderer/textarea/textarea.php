<?php
/**
* 
*/

/**
* 
*/
class CJT_Framework_View_Block_Parameter_Renderer_Textarea_Textarea
extends CJT_Framework_View_Block_Parameter_Base_Scalar {} // End class.