<?php
/**
* 
*/

/**
* 
*/
interface CJT_Framework_View_Block_Parameter_Interface_Type {
	
	/**
	* put your comment there...
	* 
	*/
	public function __toString();
	
} // End class.