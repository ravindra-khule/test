<?php
/**
* 
*/

/**
* 
*/
class CJT_Models_Package_Xml_Definition_Objects_Block_Files
extends CJT_Models_Package_Xml_Definition_Abstract {} // End class