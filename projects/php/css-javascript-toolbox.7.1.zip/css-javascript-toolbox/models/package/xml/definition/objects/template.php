<?php
/**
* 
*/

/**
* 
*/
class CJT_Models_Package_Xml_Definition_Objects_Template
extends CJT_Models_Package_Xml_Definition_Abstract {
	
	/**
	* Do nothing!
	* 
	*/
	public function processInners() {
		return $this;
	}

	/**
	* Do nothing!
	* 
	*/
	public function transit() {
		return $this;
	}
	
} // End class