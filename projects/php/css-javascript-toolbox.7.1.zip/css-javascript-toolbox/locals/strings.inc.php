<?php
/**
* This file just contain a list of other strings need to be localized!
* Almost all of the Strings are be requested througth PHP variables
* and comes from the database!
*/

/** Template States */
cssJSToolbox::getText('trash');
cssJSToolbox::getText('draft');
cssJSToolbox::getText('published');

/** Template Revision States */
cssJSToolbox::getText('release');
cssJSToolbox::getText('beta');
cssJSToolbox::getText('release-candidate');
cssJSToolbox::getText('alpha');
cssJSToolbox::getText('revision');

/** Supported Languages */
cssJSToolbox::getText('javascript');
cssJSToolbox::getText('css');
cssJSToolbox::getText('html');
cssJSToolbox::getText('php');