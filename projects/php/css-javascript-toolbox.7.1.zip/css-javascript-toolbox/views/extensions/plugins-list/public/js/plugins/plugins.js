/**
* 
*/

/**
* 
*/
(function($) {
	
	/**
	* 
	*/
	var CJTExtensionsPluginsListViewPlugins = {
		
		/**
		* put your comment there...
		* 
		*/
		init : function() {
			
		}

	}
	
	// Initioalize form when document ready!
	$($.proxy(CJTExtensionsPluginsListViewPlugins.init, CJTExtensionsPluginsListViewPlugins));
		
})(jQuery);